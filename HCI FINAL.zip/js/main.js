// Close the top banner 
var closeBanner = document.getElementById("closeBanner");
var banner = document.getElementById("banner");

if (closeBanner && banner) {
  closeBanner.addEventListener("click", function () {
    banner.hidden = true;
  });
}

//  Mobile navigation
var menu = document.getElementById("menu");
var nav = document.getElementById("nav");

if (menu && nav) {
  menu.addEventListener("click", function () {
    var open = nav.classList.toggle("open");
    menu.setAttribute("aria-expanded", String(open));
  });

  nav.addEventListener("click", function (event) {
    if (event.target.tagName === "A") {
      nav.classList.remove("open");
      menu.setAttribute("aria-expanded", "false");
    }
  });
}

//Highlight the active navigation link
var links = document.querySelectorAll("nav a");
var sections = document.querySelectorAll("main section");

if ("IntersectionObserver" in window) {
  var spy = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        links.forEach(function (link) {
          link.classList.toggle(
            "on",
            link.getAttribute("href") === "#" + entry.target.id
          );
        });
      }
    });
  }, {
    rootMargin: "-40% 0px -55% 0px"
  });

  sections.forEach(function (section) {
    spy.observe(section);
  });
}

//Animate skill bars
var bars = document.querySelectorAll(".bar i");

if ("IntersectionObserver" in window) {
  var barObserver = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.style.width =
          entry.target.dataset.level + "%";

        barObserver.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.4
  });

  bars.forEach(function (bar) {
    barObserver.observe(bar);
  });
} else {
  bars.forEach(function (bar) {
    bar.style.width = bar.dataset.level + "%";
  });
}

// Automatically update the footer year
var year = document.getElementById("year");

if (year) {
  year.textContent = new Date().getFullYear();
}

// Theme toggle
var root = document.documentElement;
var themeBtn = document.getElementById("theme");

if (themeBtn) {
  themeBtn.addEventListener("click", function () {
    var currentTheme = root.dataset.theme || "dark";
    var nextTheme = currentTheme === "dark" ? "light" : "dark";

    root.dataset.theme = nextTheme;
  });
}

// Scroll progress and back-to-top button 
var progress = document.getElementById("progress");
var toTop = document.getElementById("toTop");

window.addEventListener("scroll", function () {
  var pageHeight =
    document.documentElement.scrollHeight - window.innerHeight;

  if (progress) {
    var percentage = pageHeight > 0
      ? (window.scrollY / pageHeight) * 100
      : 0;

    progress.style.width = percentage + "%";
  }

  if (toTop) {
    toTop.hidden = window.scrollY < 600;
  }
}, {
  passive: true
});

if (toTop) {
  toTop.addEventListener("click", function () {
    var reduceMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    window.scrollTo({
      top: 0,
      behavior: reduceMotion ? "auto" : "smooth"
    });
  });
}

// Typewriter effect
const words = [
  "discovering myself",
  "learning new things",
  "gaming and dancing",
  "chasing little dreams",
  "finding my own path"
];

var typed = document.getElementById("typed");
var reduceMotion = window.matchMedia(
  "(prefers-reduced-motion: reduce)"
).matches;

if (typed && !reduceMotion) {
  var wordIndex = 0;
  var charIndex = words[0].length;
  var deleting = true;

  function typeWriter() {
    var word = words[wordIndex];

    charIndex += deleting ? -1 : 1;
    typed.textContent = word.slice(0, charIndex);

    var delay = 90;

    if (!deleting && charIndex === word.length) {
      deleting = true;
      delay = 1600;
    } else if (deleting && charIndex === 0) {
      deleting = false;
      wordIndex = (wordIndex + 1) % words.length;
      delay = 300;
    }

    window.setTimeout(typeWriter, delay);
  }

  typeWriter();
}

//Hobby "Tell me more" buttons
document.querySelectorAll(".more").forEach(function (button) {
  button.addEventListener("click", function () {
    var details = button.nextElementSibling;
    var isOpen = button.getAttribute("aria-expanded") === "true";

    button.setAttribute("aria-expanded", String(!isOpen));
    button.textContent = isOpen ? "Tell me more" : "Show less";

    if (details) {
      details.hidden = isOpen;
    }
  });
});

// ---------- Interest filters and search ----------
var chips = document.querySelectorAll(".chip");
var interestItems = document.querySelectorAll(".interests li");
var search = document.getElementById("search");
var empty = document.getElementById("empty");
var activeCategory = "all";

function applyInterestFilter() {
  var query = search ? search.value.trim().toLowerCase() : "";
  var visibleCount = 0;

  interestItems.forEach(function (item) {
    var categoryMatches =
      activeCategory === "all" ||
      item.dataset.cat === activeCategory;

    var textMatches =
      item.textContent.toLowerCase().includes(query);

    var visible = categoryMatches && textMatches;

    item.hidden = !visible;

    if (visible) {
      visibleCount++;
    }
  });

  if (empty) {
    empty.hidden = visibleCount > 0;
  }
}

chips.forEach(function (chip) {
  chip.addEventListener("click", function () {
    chips.forEach(function (item) {
      item.classList.remove("on");
    });

    chip.classList.add("on");
    activeCategory = chip.dataset.filter;

    applyInterestFilter();
  });
});

if (search) {
  search.addEventListener("input", applyInterestFilter);
}


 // ---------- Contact form validation and success popup ----------
var form = document.getElementById("form");
var errorMessage = document.getElementById("err");
var successMessage = document.getElementById("ok");

var popup = document.getElementById("successPopup");
var popupClose = document.getElementById("popupClose");

function closePopup() {
  if (popup) {
    popup.hidden = true;
  }
}

if (popupClose) {
  popupClose.addEventListener("click", closePopup);
}

if (popup) {
  popup.addEventListener("click", function (event) {
    if (event.target === popup) {
      closePopup();
    }
  });
}

if (form) {
  form.addEventListener("submit", function (event) {
    event.preventDefault();

    var nameInput = document.getElementById("name");
    var emailInput = document.getElementById("email");
    var messageInput = document.getElementById("msg");
    var message = "";

    [nameInput, emailInput, messageInput].forEach(function (input) {
      if (input) {
        input.removeAttribute("aria-invalid");
      }
    });

    if (!nameInput || !nameInput.value.trim()) {
      message = "Please enter your name.";
      if (nameInput) nameInput.setAttribute("aria-invalid", "true");

    } else if (
      !emailInput ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailInput.value.trim())
    ) {
      message = "Please enter a valid email address.";
      if (emailInput) emailInput.setAttribute("aria-invalid", "true");

    } else if (!messageInput || messageInput.value.trim().length < 10) {
      message = "Your message needs at least 10 characters.";
      if (messageInput) messageInput.setAttribute("aria-invalid", "true");
    }

    if (errorMessage) {
      errorMessage.textContent = message;
    }

    if (successMessage) {
      successMessage.hidden = true;
    }

    if (message) {
      return;
    }

    // Demo only: this displays a confirmation but does not send an email.
    form.reset();

    if (errorMessage) {
      errorMessage.textContent = "";
    }

    if (popup) {
      popup.hidden = false;
      popupClose.focus();
    } else if (successMessage) {
      successMessage.textContent =
        "Thank you! Your message was submitted successfully.";
      successMessage.hidden = false;
    }
  });
}


// ---------- Opening screen ----------
var intro = document.getElementById("intro");
var site = document.getElementById("site");
var openBtn = document.getElementById("openBtn");

function openSite(instant) {
  if (!intro || !site) {
    return;
  }

  site.removeAttribute("inert");
  document.body.classList.remove("locked");
  window.scrollTo(0, 0);

  if (instant) {
    intro.hidden = true;
    return;
  }

  intro.classList.add("opening");

  window.setTimeout(function () {
    intro.hidden = true;

    var heroHeading = document.querySelector(".hero h1");

    if (heroHeading) {
      heroHeading.setAttribute("tabindex", "-1");
      heroHeading.focus({
        preventScroll: true
      });
    }
  }, 1050);
}

if (openBtn) {
  openBtn.addEventListener("click", function () {
    openSite(false);
  });
}

// Skip the opening screen if the URL links directly to a section.
if (window.location.hash) {
  openSite(true);
}


const musicFilters = document.querySelectorAll(".music-filter");
const songCards = document.querySelectorAll(".song-card");

musicFilters.forEach((filter) => {
  filter.addEventListener("click", () => {
    const mood = filter.dataset.mood;

    musicFilters.forEach((button) => {
      button.classList.toggle("active", button === filter);
    });

    songCards.forEach((song) => {
      song.hidden =
        mood !== "all" && song.dataset.mood !== mood;
    });
  });
});
